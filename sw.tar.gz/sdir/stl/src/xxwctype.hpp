// Copyright (c) Microsoft Corporation.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

// parameters for wchar_t character type

#define CTYPE      wchar_t
#define CNAME(fun) _W##fun
