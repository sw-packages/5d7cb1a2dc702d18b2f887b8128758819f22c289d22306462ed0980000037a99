// Copyright (c) Microsoft Corporation.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

#define STDCPP_IMPLIB 1
#include "locale.cpp"
